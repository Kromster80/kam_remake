<?php $entries = array(
array('793378816','805306367','CA'),
);