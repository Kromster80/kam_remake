<?php $entries = array(
array('85983232','86015999','AE'),
);