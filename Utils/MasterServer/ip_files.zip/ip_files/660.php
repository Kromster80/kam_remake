<?php $entries = array(
array('660602880','661651455','HK'),
);