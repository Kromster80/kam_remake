<?php $entries = array(
array('680525824','687865855','US'),
);