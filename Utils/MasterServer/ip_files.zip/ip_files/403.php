<?php $entries = array(
array('40370176','40894463','DK'),
array('403701760','404226047','US'),
);