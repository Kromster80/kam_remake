<?php $entries = array(
array('4278190080','4294967295','ZZ'),
);