<?php $entries = array(
array('790102016','792002559','CA'),
);