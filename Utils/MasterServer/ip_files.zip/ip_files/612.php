<?php $entries = array(
array('612368384','616562687','CN'),
);