<?php $entries = array(
array('50331648','67108863','US'),
array('503316480','520093695','US'),
);