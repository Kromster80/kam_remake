<?php $entries = array(
array('703070208','703594495','EG'),
array('703594496','704118783','ZA'),
);