<?php $entries = array(
array('679477248','680525823','US'),
);