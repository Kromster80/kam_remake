<?php $entries = array(
array('616562688','618659839','CN'),
);