<?php $entries = array(
array('42467328','42991615','ES'),
array('4244635648','4261412863','ZZ'),
);