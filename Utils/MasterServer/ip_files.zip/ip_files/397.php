<?php $entries = array(
array('3976200192','3992977407','ZZ'),
);