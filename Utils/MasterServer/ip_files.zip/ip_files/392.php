<?php $entries = array(
array('3925868544','3942645759','ZZ'),
);