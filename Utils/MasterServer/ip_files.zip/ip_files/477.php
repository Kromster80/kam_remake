<?php $entries = array(
array('47710208','48234495','GB'),
);