<?php $entries = array(
array('42205184','42467327','KZ'),
array('4227858432','4244635647','ZZ'),
);