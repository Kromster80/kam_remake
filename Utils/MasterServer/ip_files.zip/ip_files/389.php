<?php $entries = array(
array('3892314112','3909091327','ZZ'),
);