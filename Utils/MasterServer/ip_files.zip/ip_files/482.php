<?php $entries = array(
array('48234496','49283071','IT'),
);