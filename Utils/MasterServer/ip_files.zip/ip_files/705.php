<?php $entries = array(
array('705167360','705691647','KR'),
array('705691648','706740223','KR'),
);