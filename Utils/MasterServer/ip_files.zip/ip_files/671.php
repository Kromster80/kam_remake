<?php $entries = array(
array('67108864','83886079','US'),
array('671088640','679477247','US'),
);