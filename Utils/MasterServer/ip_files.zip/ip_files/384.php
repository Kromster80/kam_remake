<?php $entries = array(
array('3841982464','3858759679','ZZ'),
);