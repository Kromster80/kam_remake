<?php $entries = array(
array('662700032','666894335','CN'),
);