<?php $entries = array(
array('2130706432','2147483647','ZZ'),
);