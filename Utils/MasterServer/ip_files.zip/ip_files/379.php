<?php $entries = array(
array('3791650816','3808428031','ZZ'),
);