<?php $entries = array(
array('3942645760','3959422975','ZZ'),
);