<?php $entries = array(
array('39583744','39845887','RU'),
array('3959422976','3976200191','ZZ'),
);