<?php $entries = array(
array('689963008','691011583','EG'),
);