<?php $entries = array(
array('706740224','707788799','KR'),
);